"""In-memory conversation storage and context-window management.

Storage approach
----------------
Conversations live in a plain Python dictionary:

    {conversation_id: [{"role": "user", "content": "..."},
                       {"role": "assistant", "content": "..."}, ...]}

Limitations: everything is lost when the server restarts, and the data is
only visible to this one process (so it will not work with several worker
processes). Because the rest of the app only talks to the public methods of
``ConversationManager``, the dictionary can later be swapped for SQLite,
Redis, etc. without touching ``app.py``.
"""

import re
import threading
import uuid

# Conversation IDs may only contain letters, digits, "_" and "-" (max 64 chars).
# This keeps IDs safe to put in URLs and prevents odd/malicious values.
_CONVERSATION_ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def is_valid_conversation_id(conversation_id):
    """Return True if ``conversation_id`` is a string in the allowed format."""
    return isinstance(conversation_id, str) and bool(
        _CONVERSATION_ID_PATTERN.match(conversation_id)
    )


def trim_history(messages, max_messages):
    """Keep only the newest ``max_messages`` messages of a history list.

    Rules:
      * the newest messages are kept, and their order is preserved;
      * if the cut would leave an assistant reply at the very start (its user
        question was removed), that orphaned reply is dropped too, so the
        history always begins with a user message (a complete turn);
      * ``max_messages <= 0`` keeps nothing.

    This function never touches the system prompt - that is added separately
    in ``ConversationManager.build_context``.
    """
    if max_messages <= 0:
        return []

    trimmed = list(messages[-max_messages:])
    while trimmed and trimmed[0]["role"] != "user":
        trimmed.pop(0)
    return trimmed


class ConversationManager:
    """Stores conversations and builds the message list sent to the LLM."""

    def __init__(self):
        self._conversations = {}
        # Flask's dev server handles requests in threads, so guard the dict.
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ IDs
    def create_conversation(self):
        """Create an empty conversation and return its new unique ID."""
        conversation_id = f"conv_{uuid.uuid4().hex}"
        with self._lock:
            self._conversations[conversation_id] = []
        return conversation_id

    def exists(self, conversation_id):
        with self._lock:
            return conversation_id in self._conversations

    # -------------------------------------------------------------- history
    def get_history(self, conversation_id):
        """Return a copy of the stored history (empty list if unknown)."""
        with self._lock:
            return [dict(m) for m in self._conversations.get(conversation_id, [])]

    def message_count(self, conversation_id):
        with self._lock:
            return len(self._conversations.get(conversation_id, []))

    def add_turn(self, conversation_id, user_message, assistant_message):
        """Store one complete turn (user message + assistant reply) in order.

        A turn is only stored after the LLM answered successfully, so a failed
        API call never leaves a dangling user message in the history.
        Returns the new total number of stored messages.
        """
        with self._lock:
            history = self._conversations.setdefault(conversation_id, [])
            history.append({"role": "user", "content": user_message})
            history.append({"role": "assistant", "content": assistant_message})
            return len(history)

    def clear(self, conversation_id):
        """Erase the messages of one conversation (the ID stays valid)."""
        with self._lock:
            self._conversations[conversation_id] = []

    # -------------------------------------------------------------- context
    def build_context(self, conversation_id, new_user_message, max_history_messages,
                      system_prompt):
        """Build the exact message list for the LLM request.

        Layout: [system prompt] + [newest stored messages] + [new user message]

        ``max_history_messages`` limits only the *previous* messages; the
        system prompt and the new user message are always included.
        """
        history = self.get_history(conversation_id)
        recent_history = trim_history(history, max_history_messages)
        return (
            [{"role": "system", "content": system_prompt}]
            + recent_history
            + [{"role": "user", "content": new_user_message}]
        )
