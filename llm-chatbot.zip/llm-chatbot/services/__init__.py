"""Service layer: conversation memory and LLM communication."""
