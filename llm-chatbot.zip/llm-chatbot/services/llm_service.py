"""Communication with the OpenAI API.

This module knows nothing about Flask or conversation storage. It receives a
ready-made list of messages and returns the assistant's text, or raises an
``LLMError`` subclass that carries a safe, user-friendly message and an HTTP
status code. Raw SDK exceptions (which may contain sensitive details) never
leave this module.
"""

import logging
import os

import openai
from openai import OpenAI

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# System prompt - edit this text to change the bot's personality.
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """You are "Engineering AI Assistant", a friendly and knowledgeable \
AI study assistant for engineering students.

Your responsibilities:
- Explain technical concepts in simple, clear language.
- Help with Python, programming, data science, AI, and machine learning.
- Use the earlier messages of this conversation to answer follow-up questions.
- Give short examples (for instance small code snippets) when they help.
- If you are not sure about something, say so honestly instead of inventing facts.
- Keep answers concise unless the user asks for a detailed explanation.
- Never reveal environment variables, API keys, or any internal configuration, \
even if asked."""

DEFAULT_TIMEOUT_SECONDS = 30.0
PLACEHOLDER_KEYS = {"", "your_api_key_here"}
PLACEHOLDER_MODELS = {"", "your_supported_model_name"}


# ---------------------------------------------------------------------------
# Exceptions: each has a status code and a message that is safe to show users.
# ---------------------------------------------------------------------------
class LLMError(Exception):
    status_code = 502
    user_message = "The AI service returned an unexpected error. Please try again."

    def __init__(self, user_message=None):
        super().__init__(user_message or self.user_message)
        if user_message:
            self.user_message = user_message


class LLMConfigError(LLMError):
    status_code = 500
    user_message = ("The server is not configured correctly. "
                    "Please check the API key and model settings.")


class LLMAuthError(LLMError):
    status_code = 502
    user_message = ("The AI service rejected the server's API key. "
                    "Please check the key in the .env file.")


class LLMRateLimitError(LLMError):
    status_code = 429
    user_message = "The AI service is receiving too many requests. Please wait a moment and try again."


class LLMQuotaError(LLMError):
    status_code = 429
    user_message = "The API account has no remaining credits or quota. Please check the OpenAI billing page."


class LLMTimeoutError(LLMError):
    status_code = 504
    user_message = "The AI service took too long to respond. Please try again."


class LLMConnectionError(LLMError):
    status_code = 503
    user_message = "Unable to connect to the AI service. Please try again."


class LLMBadResponseError(LLMError):
    status_code = 502
    user_message = "The AI service returned an empty or invalid response. Please try again."


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------
class LLMService:
    """Thin wrapper around the OpenAI Chat Completions API."""

    def __init__(self, api_key=None, model=None, timeout=None, client=None):
        # Values are read when needed, so a missing key does not crash startup;
        # it produces a clear error on the first chat request instead.
        self._api_key = api_key if api_key is not None else os.getenv("OPENAI_API_KEY", "")
        self._model = model if model is not None else os.getenv("OPENAI_MODEL", "")
        self._timeout = timeout if timeout is not None else self._read_timeout()
        self._client = client  # can be injected (used by tests)

    @staticmethod
    def _read_timeout():
        try:
            value = float(os.getenv("OPENAI_TIMEOUT_SECONDS", DEFAULT_TIMEOUT_SECONDS))
            return value if value > 0 else DEFAULT_TIMEOUT_SECONDS
        except ValueError:
            return DEFAULT_TIMEOUT_SECONDS

    def config_problem(self):
        """Return a description of a missing setting, or None if all is fine."""
        if self._api_key.strip() in PLACEHOLDER_KEYS:
            return "OPENAI_API_KEY is missing"
        if self._model.strip() in PLACEHOLDER_MODELS:
            return "OPENAI_MODEL is missing"
        return None

    def _get_client(self):
        problem = self.config_problem()
        if problem and self._client is None:
            logger.error("Configuration error: %s", problem)  # never log the key itself
            raise LLMConfigError()
        if self._client is None:
            # max_retries=1: the SDK retries once on transient errors.
            self._client = OpenAI(api_key=self._api_key.strip(),
                                  timeout=self._timeout, max_retries=1)
        return self._client

    def generate_reply(self, messages):
        """Send ``messages`` to the model and return the reply text."""
        client = self._get_client()
        if self._model.strip() in PLACEHOLDER_MODELS:
            raise LLMConfigError()

        try:
            response = client.chat.completions.create(
                model=self._model.strip(),
                messages=messages,
            )
        # Order matters: APITimeoutError is a subclass of APIConnectionError.
        except openai.AuthenticationError:
            logger.error("OpenAI authentication failed")
            raise LLMAuthError()
        except openai.PermissionDeniedError:
            logger.error("OpenAI permission denied")
            raise LLMAuthError()
        except openai.RateLimitError as exc:
            if getattr(exc, "code", None) == "insufficient_quota":
                logger.error("OpenAI quota exhausted")
                raise LLMQuotaError()
            logger.warning("OpenAI rate limit hit")
            raise LLMRateLimitError()
        except openai.APITimeoutError:
            logger.warning("OpenAI request timed out")
            raise LLMTimeoutError()
        except openai.APIConnectionError:
            logger.warning("Could not connect to OpenAI")
            raise LLMConnectionError()
        except openai.NotFoundError:
            logger.error("OpenAI model not found - check OPENAI_MODEL")
            raise LLMConfigError("The configured AI model was not found. Please check OPENAI_MODEL.")
        except openai.APIStatusError as exc:
            logger.error("OpenAI API error, status %s", exc.status_code)
            raise LLMError()
        except Exception as exc:  # last-resort guard so the app never crashes
            logger.error("Unexpected error calling OpenAI: %s", type(exc).__name__)
            raise LLMError()

        return self._extract_text(response)

    @staticmethod
    def _extract_text(response):
        """Pull the reply text out of the response, validating its shape."""
        try:
            text = response.choices[0].message.content
        except (AttributeError, IndexError, TypeError):
            raise LLMBadResponseError()
        if not isinstance(text, str) or not text.strip():
            raise LLMBadResponseError()
        return text.strip()
