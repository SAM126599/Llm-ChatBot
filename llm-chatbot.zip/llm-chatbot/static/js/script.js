// Frontend logic for the Engineering AI Assistant.
// All message text is inserted with textContent (never innerHTML), so neither
// user input nor model output can inject HTML or scripts into the page.

const WELCOME_MESSAGE =
  "Hi! I'm your Engineering AI Assistant. Ask me about Python, programming, " +
  "data science, AI or machine learning, and I'll explain it in simple terms.";
const CONNECTION_ERROR = "Unable to connect to the AI service. Please try again.";

const messagesEl = document.getElementById("messages");
const formEl = document.getElementById("chat-form");
const inputEl = document.getElementById("message-input");
const sendBtn = document.getElementById("send-btn");
const newChatBtn = document.getElementById("new-chat-btn");
const clearBtn = document.getElementById("clear-btn");
const errorBanner = document.getElementById("error-banner");

let conversationId = null;
let isLoading = false;
let errorTimer = null;

// ---------------------------------------------------------------- helpers
function showError(text) {
  errorBanner.textContent = text;
  errorBanner.hidden = false;
  clearTimeout(errorTimer);
  errorTimer = setTimeout(hideError, 8000);
}

function hideError() {
  errorBanner.hidden = true;
  errorBanner.textContent = "";
}

function scrollToBottom() {
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function addMessage(role, text) {
  const div = document.createElement("div");
  div.className = "message " + role;
  div.textContent = text; // safe: plain text only
  messagesEl.appendChild(div);
  scrollToBottom();
  return div;
}

function addTypingIndicator() {
  const div = document.createElement("div");
  div.className = "message assistant";
  div.setAttribute("aria-label", "Assistant is typing");
  const dots = document.createElement("span");
  dots.className = "typing";
  for (let i = 0; i < 3; i++) dots.appendChild(document.createElement("span"));
  div.appendChild(dots);
  messagesEl.appendChild(div);
  scrollToBottom();
  return div;
}

function setLoading(loading) {
  isLoading = loading;
  sendBtn.disabled = loading;
  inputEl.disabled = loading;
  newChatBtn.disabled = loading;
  clearBtn.disabled = loading;
  if (!loading) inputEl.focus();
}

function resetMessages() {
  messagesEl.replaceChildren();
  addMessage("assistant", WELCOME_MESSAGE);
}

function autoResizeInput() {
  inputEl.style.height = "auto";
  inputEl.style.height = Math.min(inputEl.scrollHeight, 140) + "px";
}

// Calls the backend; returns parsed JSON or throws an Error with a readable message.
async function postJson(url, body) {
  let response;
  try {
    response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch (networkError) {
    throw new Error(CONNECTION_ERROR);
  }

  let data = null;
  try {
    data = await response.json();
  } catch (parseError) {
    data = null; // server answered with something that is not JSON
  }

  if (!response.ok) {
    const message = data && typeof data.error === "string" ? data.error : CONNECTION_ERROR;
    throw new Error(message);
  }
  if (data === null) throw new Error(CONNECTION_ERROR);
  return data;
}

async function startNewConversation() {
  const data = await postJson("/api/conversations");
  conversationId = data.conversation_id;
}

// ----------------------------------------------------------------- events
formEl.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (isLoading) return; // prevent duplicate submissions

  const text = inputEl.value.trim();
  if (!text) return;

  hideError();
  setLoading(true);
  addMessage("user", text);
  inputEl.value = "";
  autoResizeInput();
  const typingEl = addTypingIndicator();

  try {
    if (!conversationId) await startNewConversation();
    const data = await postJson("/api/chat", {
      conversation_id: conversationId,
      message: text,
    });
    typingEl.remove();
    addMessage("assistant", data.reply);
  } catch (error) {
    typingEl.remove();
    showError(error.message);
  } finally {
    setLoading(false);
  }
});

// Enter sends the message; Shift+Enter inserts a new line.
inputEl.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    formEl.requestSubmit();
  }
});
inputEl.addEventListener("input", autoResizeInput);

newChatBtn.addEventListener("click", async () => {
  if (isLoading) return;
  hideError();
  setLoading(true);
  try {
    await startNewConversation(); // brand-new ID => brand-new, empty history
    resetMessages();
  } catch (error) {
    showError(error.message);
  } finally {
    setLoading(false);
  }
});

clearBtn.addEventListener("click", async () => {
  if (isLoading) return;
  hideError();
  setLoading(true);
  try {
    if (conversationId) {
      await postJson("/api/conversations/" + encodeURIComponent(conversationId) + "/clear");
    }
    resetMessages();
  } catch (error) {
    showError(error.message);
  } finally {
    setLoading(false);
  }
});

// ------------------------------------------------------------------- init
resetMessages();
startNewConversation().catch(() => {
  // Not fatal: a new conversation is created on the first message instead.
});
inputEl.focus();
