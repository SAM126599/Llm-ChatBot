"""Tests for how LLMService maps OpenAI SDK errors (no network used)."""

from types import SimpleNamespace

import httpx
import openai
import pytest

from services.llm_service import (
    LLMAuthError, LLMBadResponseError, LLMConfigError, LLMConnectionError, LLMError,
    LLMQuotaError, LLMRateLimitError, LLMService, LLMTimeoutError,
)

REQUEST = httpx.Request("POST", "https://api.openai.com/v1/chat/completions")
MESSAGES = [{"role": "system", "content": "s"}, {"role": "user", "content": "hi"}]


def fake_client(exception=None, response=None):
    def create(**kwargs):
        if exception is not None:
            raise exception
        return response
    return SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create)))


def make_service(client):
    return LLMService(api_key="sk-test", model="test-model", client=client)


def status_error(cls, status, body=None):
    return cls("boom", response=httpx.Response(status, request=REQUEST), body=body)


def good_response(text):
    return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content=text))])


def test_success_returns_text():
    service = make_service(fake_client(response=good_response("  Hello!  ")))
    assert service.generate_reply(MESSAGES) == "Hello!"


@pytest.mark.parametrize("exception, expected", [
    (status_error(openai.AuthenticationError, 401), LLMAuthError),
    (status_error(openai.PermissionDeniedError, 403), LLMAuthError),
    (status_error(openai.RateLimitError, 429), LLMRateLimitError),
    (status_error(openai.RateLimitError, 429, body={"code": "insufficient_quota"}), LLMQuotaError),
    (openai.APITimeoutError(request=REQUEST), LLMTimeoutError),
    (openai.APIConnectionError(request=REQUEST), LLMConnectionError),
    (status_error(openai.NotFoundError, 404), LLMConfigError),
    (status_error(openai.InternalServerError, 500), LLMError),
    (RuntimeError("anything"), LLMError),
])
def test_sdk_errors_become_safe_llm_errors(exception, expected):
    service = make_service(fake_client(exception=exception))
    with pytest.raises(expected) as info:
        service.generate_reply(MESSAGES)
    assert type(info.value) is expected
    assert "sk-test" not in info.value.user_message


@pytest.mark.parametrize("response", [
    good_response(None),
    good_response("   "),
    SimpleNamespace(choices=[]),
    SimpleNamespace(),
])
def test_empty_or_invalid_response_is_rejected(response):
    service = make_service(fake_client(response=response))
    with pytest.raises(LLMBadResponseError):
        service.generate_reply(MESSAGES)


@pytest.mark.parametrize("key, model", [
    ("", "some-model"),
    ("your_api_key_here", "some-model"),
    ("sk-real", ""),
    ("sk-real", "your_supported_model_name"),
])
def test_missing_configuration_raises_config_error(key, model):
    service = LLMService(api_key=key, model=model)
    assert service.config_problem() is not None
    with pytest.raises(LLMConfigError):
        service.generate_reply(MESSAGES)


def test_missing_key_gives_controlled_http_error():
    from app import create_app
    app = create_app(llm_service=LLMService(api_key="", model="m"))
    response = app.test_client().post("/api/chat", json={"conversation_id": "c", "message": "hi"})
    assert response.status_code == 500
    assert "not configured" in response.get_json()["error"]
