"""Automated tests for the Flask API (LLM mocked)."""

from services.llm_service import SYSTEM_PROMPT, LLMRateLimitError, LLMTimeoutError

from tests.conftest import chat


# Test 1 - basic call ---------------------------------------------------------
def test_basic_chat_returns_reply(client, fake_llm):
    fake_llm.fixed_reply = "Hello from the model"
    response = chat(client, "conversation_123", "Hi there")
    assert response.status_code == 200
    body = response.get_json()
    assert body == {
        "conversation_id": "conversation_123",
        "reply": "Hello from the model",
        "history_messages": 2,
    }


# Test 2 - memory -------------------------------------------------------------
def test_memory_earlier_messages_reach_the_model(client, fake_llm):
    # limit is 4 history messages = 2 turns, so use a roomy limit for this test
    from app import create_app
    app = create_app(llm_service=fake_llm, max_history_messages=10)
    c = app.test_client()
    chat(c, "mem", "My name is Sam.")
    chat(c, "mem", "I am studying computer science.")
    chat(c, "mem", "I am interested in machine learning.")
    reply = chat(c, "mem", "What is my name, and what am I studying?").get_json()["reply"]
    assert "My name is Sam." in reply
    assert "I am studying computer science." in reply

    # Order and roles of what the model received on the last request
    last_request = fake_llm.calls[-1]
    roles = [m["role"] for m in last_request]
    assert roles == ["system", "user", "assistant", "user", "assistant", "user", "assistant", "user"]
    assert last_request[1]["content"] == "My name is Sam."


# Test 3 - isolation ----------------------------------------------------------
def test_conversations_are_isolated(client, fake_llm):
    chat(client, "alice", "My secret word is pineapple.")
    reply = chat(client, "bob", "What is my secret word?").get_json()["reply"]
    assert "pineapple" not in reply
    assert all("pineapple" not in m["content"] for m in fake_llm.calls[-1])


# Test 4 - context window management ------------------------------------------
def test_context_window_truncates_but_keeps_system_prompt(client, fake_llm):
    # client fixture uses max_history_messages=4
    for i in range(1, 6):
        chat(client, "long", f"message {i}")

    sent = fake_llm.calls[-1]
    assert sent[0] == {"role": "system", "content": SYSTEM_PROMPT}
    # system prompt + last 4 stored messages (turns 3 and 4) + the new message = 6
    assert len(sent) == 1 + 4 + 1
    assert sent[1]["role"] == "user"  # never starts with an orphaned assistant reply
    user_texts = [m["content"] for m in sent if m["role"] == "user"]
    assert "message 1" not in user_texts and "message 2" not in user_texts
    assert user_texts == ["message 3", "message 4", "message 5"]
    # The full history is still stored even though only part was sent.
    assert client.post("/api/chat", json={"conversation_id": "long", "message": "x"}).get_json()[
        "history_messages"] == 12


# Test 5 - validation errors --------------------------------------------------
def test_empty_message_is_rejected(client, fake_llm):
    response = chat(client, "c1", "   ")
    assert response.status_code == 400
    assert response.get_json()["error"] == "Message cannot be empty."
    assert fake_llm.calls == []


def test_missing_message_field(client):
    response = client.post("/api/chat", json={"conversation_id": "c1"})
    assert response.status_code == 400


def test_invalid_json_body(client):
    response = client.post("/api/chat", data="not json", content_type="application/json")
    assert response.status_code == 400
    assert "valid JSON" in response.get_json()["error"]


def test_missing_conversation_id(client):
    response = client.post("/api/chat", json={"message": "hi"})
    assert response.status_code == 400


def test_invalid_conversation_id(client):
    response = chat(client, "../etc/passwd", "hi")
    assert response.status_code == 400
    response = chat(client, "x" * 65, "hi")
    assert response.status_code == 400


def test_message_too_long(client):
    assert chat(client, "c1", "a" * 4001).status_code == 400


# Test 6 - API failure --------------------------------------------------------
def test_llm_error_returns_controlled_response(client, fake_llm):
    fake_llm.error = LLMRateLimitError()
    response = chat(client, "c1", "hello")
    assert response.status_code == 429
    assert "error" in response.get_json()

    fake_llm.error = LLMTimeoutError()
    assert chat(client, "c1", "hello").status_code == 504


def test_unexpected_exception_does_not_leak_details(client, fake_llm):
    fake_llm.error = RuntimeError("secret internal detail sk-12345")
    response = chat(client, "c1", "hello")
    assert response.status_code == 500
    assert "secret" not in response.get_data(as_text=True)
    assert "sk-12345" not in response.get_data(as_text=True)


def test_failed_call_does_not_store_history(client, fake_llm):
    fake_llm.error = LLMTimeoutError()
    chat(client, "c1", "first")
    fake_llm.error = None
    body = chat(client, "c1", "second").get_json()
    assert body["history_messages"] == 2  # only the successful turn was stored
    assert [m["content"] for m in fake_llm.calls[-1] if m["role"] == "user"] == ["second"]


# Test 7 - new conversation / clear -------------------------------------------
def test_new_conversation_starts_with_empty_history(client, fake_llm):
    first_id = client.post("/api/conversations").get_json()["conversation_id"]
    chat(client, first_id, "I like robots.")

    second = client.post("/api/conversations")
    assert second.status_code == 201
    second_id = second.get_json()["conversation_id"]
    assert second_id != first_id

    body = chat(client, second_id, "Do you remember me?").get_json()
    assert body["history_messages"] == 2
    assert all("robots" not in m["content"] for m in fake_llm.calls[-1])


def test_clear_conversation(client, fake_llm):
    chat(client, "c1", "remember banana")
    response = client.post("/api/conversations/c1/clear")
    assert response.status_code == 200
    assert response.get_json()["history_messages"] == 0
    chat(client, "c1", "what did I say?")
    assert all("banana" not in m["content"] for m in fake_llm.calls[-1])


def test_clear_rejects_invalid_id(client):
    assert client.post("/api/conversations/bad$id/clear").status_code == 400


# Misc ------------------------------------------------------------------------
def test_index_page_loads(client):
    response = client.get("/")
    assert response.status_code == 200
    assert b"Engineering AI Assistant" in response.data


def test_unknown_route_returns_json_404(client):
    response = client.get("/api/nope")
    assert response.status_code == 404
    assert response.get_json()["error"] == "Not found."
