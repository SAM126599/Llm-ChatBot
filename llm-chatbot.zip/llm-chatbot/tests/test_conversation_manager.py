"""Unit tests for conversation storage and truncation logic."""

from services.conversation_manager import ConversationManager, is_valid_conversation_id, trim_history


def make_history(turns):
    history = []
    for i in range(1, turns + 1):
        history.append({"role": "user", "content": f"u{i}"})
        history.append({"role": "assistant", "content": f"a{i}"})
    return history


def test_trim_keeps_newest_messages_in_order():
    trimmed = trim_history(make_history(5), 4)
    assert [m["content"] for m in trimmed] == ["u4", "a4", "u5", "a5"]


def test_trim_drops_orphaned_assistant_message():
    # last 3 would start with an assistant reply -> it must be dropped
    trimmed = trim_history(make_history(5), 3)
    assert [m["content"] for m in trimmed] == ["u5", "a5"]


def test_trim_with_short_history_returns_everything():
    assert len(trim_history(make_history(1), 10)) == 2


def test_trim_zero_keeps_nothing():
    assert trim_history(make_history(3), 0) == []


def test_build_context_always_has_system_prompt_first_and_new_message_last():
    manager = ConversationManager()
    for i in range(10):
        manager.add_turn("c", f"q{i}", f"a{i}")
    context = manager.build_context("c", "new question", 2, "SYSTEM")
    assert context[0] == {"role": "system", "content": "SYSTEM"}
    assert context[-1] == {"role": "user", "content": "new question"}
    assert len(context) == 1 + 2 + 1


def test_build_context_with_zero_history_still_has_system_prompt():
    manager = ConversationManager()
    manager.add_turn("c", "q", "a")
    context = manager.build_context("c", "hi", 0, "SYSTEM")
    assert [m["role"] for m in context] == ["system", "user"]


def test_create_conversation_ids_are_unique_and_valid():
    manager = ConversationManager()
    ids = {manager.create_conversation() for _ in range(50)}
    assert len(ids) == 50
    assert all(is_valid_conversation_id(i) for i in ids)


def test_get_history_returns_copy():
    manager = ConversationManager()
    manager.add_turn("c", "q", "a")
    manager.get_history("c")[0]["content"] = "tampered"
    assert manager.get_history("c")[0]["content"] == "q"


def test_valid_id_rules():
    assert is_valid_conversation_id("conversation_123")
    assert not is_valid_conversation_id("")
    assert not is_valid_conversation_id("has space")
    assert not is_valid_conversation_id(None)
    assert not is_valid_conversation_id(123)
