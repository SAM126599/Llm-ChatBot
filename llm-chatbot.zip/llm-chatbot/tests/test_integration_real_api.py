"""Optional integration test that calls the REAL OpenAI API.

Skipped by default (it needs a valid key and may use paid credits).
Run it on Windows PowerShell with:

    $env:RUN_INTEGRATION = "1"
    pytest tests/test_integration_real_api.py -v -s
"""

import os

import pytest
from dotenv import load_dotenv

load_dotenv()

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(os.getenv("RUN_INTEGRATION") != "1",
                       reason="set RUN_INTEGRATION=1 to call the real OpenAI API"),
]


def test_real_llm_remembers_earlier_messages():
    from app import create_app

    client = create_app().test_client()
    conversation_id = "integration_test"

    def say(text):
        response = client.post("/api/chat", json={"conversation_id": conversation_id, "message": text})
        assert response.status_code == 200, response.get_json()
        return response.get_json()["reply"]

    say("My name is Sam.")
    say("I am studying computer science.")
    say("I am interested in machine learning.")
    answer = say("What is my name, and what am I studying?").lower()
    print("\nModel answer:", answer)

    assert "sam" in answer
    assert "computer science" in answer
