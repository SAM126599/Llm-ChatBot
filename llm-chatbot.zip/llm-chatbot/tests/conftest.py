"""Shared test helpers: a fake LLM service so tests need no real API call."""

import pytest

from app import create_app


class FakeLLMService:
    """Stands in for LLMService. Records every request it receives.

    Its reply is built from the messages it was *given*, so a test can prove
    what information actually reached the model:
        reply = "REMEMBERED: " + all user messages in the request, joined by " | "
    """

    def __init__(self):
        self.calls = []          # list of message lists, one per request
        self.error = None        # set to an exception instance to simulate failure
        self.fixed_reply = None  # set to a string to force a specific reply

    def config_problem(self):
        return None

    def generate_reply(self, messages):
        self.calls.append([dict(m) for m in messages])
        if self.error is not None:
            raise self.error
        if self.fixed_reply is not None:
            return self.fixed_reply
        user_texts = [m["content"] for m in messages if m["role"] == "user"]
        return "REMEMBERED: " + " | ".join(user_texts)


@pytest.fixture
def fake_llm():
    return FakeLLMService()


@pytest.fixture
def client(fake_llm):
    app = create_app(llm_service=fake_llm, max_history_messages=4)
    app.config["TESTING"] = True
    return app.test_client()


def chat(client, conversation_id, message):
    """Helper: POST one chat message."""
    return client.post("/api/chat", json={"conversation_id": conversation_id, "message": message})
